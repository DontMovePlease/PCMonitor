﻿#region License
/* Copyright 2018 James F. Bellinger <http://software.seekye.com/hidsharp>

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing,
   software distributed under the License is distributed on an
   "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   KIND, either express or implied.  See the License for the
   specific language governing permissions and limitations
   under the License. */
#endregion

using System.Collections.Generic;

namespace HidSharp
{
    sealed class LocalDeviceList : DeviceList
    {
        /*
        public override BleDiscovery BeginBleDiscovery()
        {
            return Platform.HidSelector.Instance.BeginBleDiscovery();
        }
        */

        public override IEnumerable<Device> GetDevices(DeviceTypes types)
        {
            return Platform.HidSelector.Instance.GetDevices(types);
        }

        public override IEnumerable<Device> GetAllDevices()
        {
            return GetDevices(DeviceTypes.Hid | DeviceTypes.Serial | DeviceTypes.Ble);
        }

        public override void UninstallDevice(int vendorID, int productID, DeviceUninstallOptions options)
        {
            Platform.HidSelector.Instance.UninstallDevice(vendorID, productID, options);
        }

        public override string ToString()
        {
            return Platform.HidSelector.Instance.FriendlyName; // This value is useful for debugging.
        }

        public override bool AreDriversBeingInstalled
        {
            get { return Platform.HidSelector.Instance.AreDriversBeingInstalled; }
        }

        public override bool CanUninstallDevices
        {
            get { return Platform.HidSelector.Instance.CanUninstallDevices; }
        }
    }
}
